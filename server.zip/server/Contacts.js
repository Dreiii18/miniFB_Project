const contacts = [
    {
        image: "https://scontent.fyvr3-1.fna.fbcdn.net/v/t39.30808-1/461204377_10115852257979731_20136418769041878_n.jpg?stp=c48.8.384.383a_dst-jpg_p480x480&_nc_cat=1&ccb=1-7&_nc_sid=50d2ac&_nc_ohc=nIQTMwfFRhAQ7kNvgH1q4gG&_nc_zt=24&_nc_ht=scontent.fyvr3-1.fna&_nc_gid=AINgGQyeCXGli7Y2CsJ-lGm&oh=00_AYBUeNBMuBvZ90krGIotb7Y601nymtJnDZNbZngeONzqfw&oe=674B2B70",
        text: "Mark Zuckerberg",
    },
    {
        image: "https://scontent.fyvr3-1.fna.fbcdn.net/v/t39.30808-1/432176453_961740661984419_3874775538159957915_n.jpg?stp=dst-jpg_s480x480_tt6&_nc_cat=1&ccb=1-7&_nc_sid=f4b9fd&_nc_ohc=4KRQBqQkdosQ7kNvgEwuDe5&_nc_zt=24&_nc_ht=scontent.fyvr3-1.fna&_nc_gid=AlhzAR9G4-Wn370ZiqHi4aQ&oh=00_AYBfCYsFkXsCdIGe1YVp4OK0JSImo3DtdoGKIPsqSCmUEg&oe=674B4D76",
        text: "Taylor Swift",
    },
    {
        image: "https://scontent.fyvr3-1.fna.fbcdn.net/v/t39.30808-1/461936413_1091563265667901_6592324197866706840_n.jpg?stp=dst-jpg_s480x480_tt6&_nc_cat=1&ccb=1-7&_nc_sid=f4b9fd&_nc_ohc=QMBAmqZTOaIQ7kNvgEEsB-J&_nc_zt=24&_nc_ht=scontent.fyvr3-1.fna&_nc_gid=AhkQH4nROIt-cruV5POQIbr&oh=00_AYAFygUbusi_IWvO-dW2oC4t8nlp09zM-asS62rahrBKrw&oe=674B3767",
        text: "LeBron James",
    },
    {
        image: "https://scontent.fyvr3-1.fna.fbcdn.net/v/t39.30808-1/431280363_957205379092002_6286914652591064187_n.jpg?stp=dst-jpg_s480x480_tt6&_nc_cat=1&ccb=1-7&_nc_sid=f4b9fd&_nc_ohc=JoVpKVYP4kIQ7kNvgEJBijI&_nc_zt=24&_nc_ht=scontent.fyvr3-1.fna&_nc_gid=AHEWKmfXY4pXd2Gr5_NsYLl&oh=00_AYCR4gtO-qUyrTNLuOyxeb3JO7QfrPouaMmgbvgeIgLbtA&oe=674B4178",
        text: "Ariana Grande",
    },
    {
        image: "https://scontent.fyvr3-1.fna.fbcdn.net/v/t39.30808-1/448474001_1102716254548247_2613997786866384047_n.jpg?stp=dst-jpg_s480x480_tt6&_nc_cat=1&ccb=1-7&_nc_sid=f4b9fd&_nc_ohc=irV0agrun60Q7kNvgEjkZQt&_nc_zt=24&_nc_ht=scontent.fyvr3-1.fna&_nc_gid=AecF3QyWU1-C6fg0Iqn_gF5&oh=00_AYCfgi1aYiHtwOQFuHVsDzYOchhIty6qtlUI6ktBynSkdw&oe=674B17E1",
        text: "Cristiano Ronaldo"
    },
];

module.exports = contacts;